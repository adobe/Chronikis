library(testthat)
library(chronikis)

test_check("chronikis")
